<?php
include("common_css.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
a.ss
{

font-size:12px;color:#2F6E4A;font-family:Verdana;text-decoration:none;
}
</style>
</head>
<body>
<form>
<table align="center" border="0">
<tr><td>
<table border="1" style="border-color:#D6DEBD; border-collapse:collapse">
<tr><td><a href="http://emedoutlet.com" ><img src="temp_top.gif" border="0" alt="Emedoutlet-Online Pharmacy  Customer service:+1(646) 502 8606"/></a></td></tr>
<tr><td>
<table align="left"><tr>
<td><a href="http://emedoutlet.com" class="ss">Home</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">All products</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Faq</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Contact Us</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">My Account</a>&nbsp;</td>
<td width="260"></td>
<td><font color="#0C542D" size="2"><?php echo date("F j, Y");   ?></font></td>
</tr></table>
</td></tr>
</table>
<br>
<br />
<tr><td>
<table><tr>
<td align="left">
<table  border="1" bgcolor="#E7EFDA" style="border-collapse:collapse">
<tr><td><a href="http://emedoutlet.com"><img src="tepm_images/temp_left1.gif" border="0" alt="Search medicines in Emedoutlet.com"/></a></td></tr>
<tr><td>



<tr><td width="30"><font color="#0C542D"><b>Best Seller</b></font></td></tr>

<tr><td>
<table  align="center" border="1" style="border-color:#D6DEBD; border-collapse:collapse">

<tr><td><img align="middle" src="temp_left2-1.gif" alt="best selling medicine" /></td></tr>
<tr><td align="center"><font size="2" color="#3657E4"><b>Generic Lipitor</font></td></tr>
<tr><td><hr color="#D6DEBD"</td></tr>
<tr><td><img src="temp_left2-2.gif" alt="best selling medicine"/></td></tr>
<tr><td align="center"><font size="2"color="#3657E4"><b>Generic Plavix</font></td></tr>

</td></tr>
</table>
</td></tr>


</td></tr>
<tr><td><a href="http://emedoutlet.com"><img src="temp_left3.gif" border="0" alt="Write a review"/></a></td></tr>
</table>
</td>
<td valign="top" align="right">
<table>
<tr><td><a href="http://emedoutlet.com"><img src="temp_right.gif" border="0" alt="best online pharmacy secure payment option"/></a></td></tr>
<tr><td>$body</td></tr>
</table>
</td>
</tr></table>
</td></tr>

<tr><td>
<table bgcolor="#F2F6EB" style="border-collapse:collapse">
<tr><td valign="top"><hr size="5" color="#D6DEBD" /></td></tr>
<tr style="background-color:#F2F6EB"><td>
<table><tr>
<td><a href="http://emedoutlet.com" class="ss">Home</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Contact us</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Faq</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Shipping policy</a>&nbsp;|</td>
<td><a href="http://emedoutlet.com" class="ss">Privacy policy</a>&nbsp;</td>
<td width="360"></td>
</tr></table>
<br /><br /><br /><br /><br /><br />
</td></tr>
</table>
</td></tr>
</table>
</form>
</body>
</html>
<?php function email($body) { ?>
<?php } ?>