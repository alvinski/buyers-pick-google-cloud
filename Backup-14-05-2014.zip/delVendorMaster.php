<?php
include('database.php');
$json = json_decode($_REQUEST['vendor_master_id'], true);
foreach($json as $key=>$values)
{

	$id = $values['id'];
	/*
	$vendor_name = $values['vendor_name'];
	$vendor_title = $values['vendor_title'];
	$tags = $values['tags'];
	$created_date = $values['created_date'];
	$description = $values['description'];
	$security_pin = $values['security_pin'];
	$old_security_pin = $values['old_security_pin'];
	$last_modified_security_pin = $values['last_modified_security_pin'];
	$geo_latitude = $values['geo_latitude'];
	$geo_longitude = $values['geo_longitude'];
	$last_modified_date = $values['last_modified_date'];
	$is_deleted = $values['is_deleted'];
	$delete_date = $values['delete_date'];
	$industry_id = $values['industry_id'];
	$last_modified = $values['last_modified'];
	*/
	//echo "ID : " . $id."<br>";
	//if($id!="")
	//{
		$sqlDel = mysql_query("update ba_tbl_vendor_master set is_deleted = '1' where id = '$id'");
		if(mysql_affected_rows()==1)
		{
			$sqlSelect = mysql_query("select id from ba_tbl_vendor_master where id = '$id'");
			$rowSelect = mysql_fetch_assoc($sqlSelect);
			$updated_id = $rowSelect["id"];
			$arr_vendor_master[] = array("id"=>$updated_id);
			
			/************** changing/updating rows in tbl_vendor related to the deleted vendor_master **************/
			
			$sqlVendorUpdate = mysql_query("update ba_tbl_vendor set is_deleted = '1' where vendor_id = '$updated_id'"); //Updating all rows releted to vendor_master_id
			
			$sqlVendorSelect = mysql_query("select id from ba_tbl_vendor where vendor_id = '$updated_id'"); //Selecting all updated ids related to vendor master
			while($rowVendorSelect = mysql_fetch_assoc($sqlVendorSelect))
			{
				$arrayVendor[] = array("id"=>$rowVendorSelect["id"]); //Creating array of ids from ba_tbl_vendor
			}
			
			/******************** END ******************/
			
			/************** changing/updating rows in tbl_content related to the deleted vendor_master **************/
			
			$sqlContentUpdate = mysql_query("update ba_tbl_content set is_deleted = '1' where vendor_id = '$updated_id'"); //Updating all rows releted to vendor_master_id
			
			$sqlContentSelect = mysql_query("select id from ba_tbl_content where vendor_id = '$updated_id'"); //Selecting all updated ids related to vendor master
			while($rowContentSelect = mysql_fetch_assoc($sqlContentSelect))
			{
				$arrayContent[] = array("id"=>$rowContentSelect["id"]); //Creating array of ids from ba_tbl_vendor
			}
			
			/******************** END ******************/
		}
		//}
	
	
}
if($arr_vendor_master==null)
{
		$arr_vendor_master = array();	
}
if($arrayVendor==null)
{
		$arrayVendor = array();	
}	
if($arrayContent==null)
{
		$arrayContent = array();	
}		
$data['vendor'] = $arr_vendor_master;
$data['vendor_contact'] = $arrayVendor;
$data['content'] = $arrayContent;
$json_final = json_encode($data);
print_r($json_final);
?>