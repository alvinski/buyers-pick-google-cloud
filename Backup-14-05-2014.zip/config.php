<?php
/**
 * Database config variables
 */
define("DB_HOST", ":/cloudsql/skibuyerspick:buyerspick");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "buyerspick");
/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyBUyXOii7ZvVBKKMBvhCIJ8Zc-_s_Btk_Q"); // Place your Google API Key
?>