<?php
/**
 * Database config variables
 */
define("DB_HOST", "74.208.47.152");
define("DB_USER", "root");
define("DB_PASSWORD", "javed@77");
define("DB_DATABASE", "buyerspick");
/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyBUyXOii7ZvVBKKMBvhCIJ8Zc-_s_Btk_Q"); // Place your Google API Key
?>

#d6083b

#d6083b