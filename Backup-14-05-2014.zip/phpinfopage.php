<?php
phpinfo();
echo "TESTING Another Page....."
?>
