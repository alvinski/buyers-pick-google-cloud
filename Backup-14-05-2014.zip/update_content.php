<?php
include('database.php');
$json = json_decode($_POST['update_vendor'], true);
foreach($json as $key_vendor=>$values)
{
	$id = $_POST['id'];
	//$empty_id = "";
	$content_name = $_POST['content_name'];
	$vendor_id = $_POST['vendor_id'];
	$content_name = $_POST['content_name'];
	$path = $_POST['path'];
	$cloud_path = $_POST['cloud_path'];
	$tags = $_POST['tags'];
	$title = $_POST['title'];
	$content_size = $_POST['content_size'];
	$description = $_POST['description'];
	$website = $_POST['website'];
	$created_date = $_POST['created_date'];
	$update_date = $_POST['update_date'];
	$is_deleted = $_POST['is_deleted'];
	$delete_date = $_POST['delete_date'];
	$path = $_POST['path'];
	//$sync_status = $_POST['sync_status'];
	$industry_id = $_POST['industry_id'];
	$type = $_POST['type'];
	$type = $_POST['type'];
	$sync_status = 1;
	$update_status = 1;
}